import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/game_model.dart';
import '../utils/sound_service.dart';
import '../widgets/game_widgets.dart';
import 'games/number_pop_screen.dart';
import 'games/color_match_screen.dart';
import 'games/memory_flip_screen.dart';

class GamesScreen extends StatefulWidget {
  static const String routeName = '/games';
  const GamesScreen({Key? key}) : super(key: key);

  @override
  State<GamesScreen> createState() => _GamesScreenState();
}

class _GamesScreenState extends State<GamesScreen> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  final SoundService _sound = SoundService();
  final Map<GameId, int> _highScores = {};

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 8))
      ..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    super.dispose();
  }

  void _openGame(GameModel game) async {
    await _sound.playPop();
    if (!mounted) return;

    Widget screen;
    switch (game.id) {
      case GameId.numberPop:
        screen = const NumberPopScreen();
        break;
      case GameId.colorMatch:
        screen = const ColorMatchScreen();
        break;
      case GameId.memoryFlip:
        screen = const MemoryFlipScreen();
        break;
    }

    final result = await Navigator.of(context).push<int>(
      PageRouteBuilder(
        pageBuilder: (_, anim, __) => screen,
        transitionsBuilder: (_, anim, __, child) {
          return ScaleTransition(
            scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
            child: FadeTransition(opacity: anim, child: child),
          );
        },
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );

    if (result != null) {
      setState(() {
        final prev = _highScores[game.id] ?? 0;
        if (result > prev) _highScores[game.id] = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: _bgCtrl,
        builder: (_, __) => Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color.lerp(const Color(0xFF1a1a2e), const Color(0xFF16213e), math.sin(_bgCtrl.value * math.pi))!,
                Color.lerp(const Color(0xFF0f3460), const Color(0xFF533483), math.sin(_bgCtrl.value * math.pi))!,
              ],
            ),
          ),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                Expanded(
                  child: _buildGameGrid(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FadeTransition(
                opacity: _entranceCtrl,
                child: const Text(
                  'Game Zone! 🎮',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: -0.5,
                  ),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'Pick a game and have fun!',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.white.withOpacity(0.6),
                ),
              ),
            ],
          ),
          const Spacer(),
          _MuteButton(sound: _sound),
          const SizedBox(width: 8),
          _FloatingBubbles(),
        ],
      ),
    );
  }

  Widget _buildGameGrid() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          for (int i = 0; i < kGames.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: Offset(0, 0.3 + i * 0.1),
                  end: Offset.zero,
                ).animate(CurvedAnimation(
                  parent: _entranceCtrl,
                  curve: Interval(i * 0.15, 1.0, curve: Curves.easeOutCubic),
                )),
                child: FadeTransition(
                  opacity: CurvedAnimation(
                    parent: _entranceCtrl,
                    curve: Interval(i * 0.15, 1.0),
                  ),
                  child: _GameCard(
                    game: kGames[i],
                    highScore: _highScores[kGames[i].id],
                    onTap: () => _openGame(kGames[i]),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ── Game card ────────────────────────────────────────────────────────────────

class _GameCard extends StatefulWidget {
  final GameModel game;
  final int? highScore;
  final VoidCallback onTap;
  const _GameCard({required this.game, required this.onTap, this.highScore});

  @override
  State<_GameCard> createState() => _GameCardState();
}

class _GameCardState extends State<_GameCard> with SingleTickerProviderStateMixin {
  late AnimationController _hoverCtrl;
  late Animation<double> _scale;
  late Animation<double> _elevate;

  @override
  void initState() {
    super.initState();
    _hoverCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 180));
    _scale = Tween<double>(begin: 1.0, end: 1.03).animate(
      CurvedAnimation(parent: _hoverCtrl, curve: Curves.easeOut),
    );
    _elevate = Tween<double>(begin: 0, end: 8).animate(_hoverCtrl);
  }

  @override
  void dispose() {
    _hoverCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _hoverCtrl.forward(),
      onTapUp: (_) { _hoverCtrl.reverse(); widget.onTap(); },
      onTapCancel: () => _hoverCtrl.reverse(),
      child: AnimatedBuilder(
        animation: _hoverCtrl,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            height: 120,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [widget.game.primaryColor, widget.game.secondaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: widget.game.primaryColor.withOpacity(0.5),
                  blurRadius: 16 + _elevate.value,
                  offset: Offset(0, 4 + _elevate.value / 2),
                ),
              ],
            ),
            child: Stack(
              children: [
                // Background circles
                Positioned(
                  right: -20,
                  top: -20,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.1),
                    ),
                  ),
                ),
                Positioned(
                  right: 30,
                  bottom: -30,
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.08),
                    ),
                  ),
                ),
                // Content
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Center(
                          child: Text(
                            widget.game.emoji,
                            style: const TextStyle(fontSize: 32),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              widget.game.title,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                                letterSpacing: -0.3,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              widget.game.description,
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.white.withOpacity(0.85),
                              ),
                              maxLines: 2,
                            ),
                            if (widget.highScore != null) ...[
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  const Icon(Icons.emoji_events_rounded, color: Color(0xFFFFE66D), size: 14),
                                  const SizedBox(width: 4),
                                  Text(
                                    'Best: ${widget.highScore}',
                                    style: const TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFFFFE66D),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.25),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              'Ages ${widget.game.minAge}-${widget.game.maxAge}',
                              style: const TextStyle(fontSize: 11, color: Colors.white, fontWeight: FontWeight.w600),
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Icon(Icons.play_circle_rounded, color: Colors.white, size: 32),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Mute button ──────────────────────────────────────────────────────────────

class _MuteButton extends StatefulWidget {
  final SoundService sound;
  const _MuteButton({required this.sound});

  @override
  State<_MuteButton> createState() => _MuteButtonState();
}

class _MuteButtonState extends State<_MuteButton> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() => widget.sound.toggleMute());
      },
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(
          widget.sound.isMuted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
          color: Colors.white,
          size: 20,
        ),
      ),
    );
  }
}

// ── Floating animated bubbles (decorative) ───────────────────────────────────

class _FloatingBubbles extends StatefulWidget {
  @override
  State<_FloatingBubbles> createState() => _FloatingBubblesState();
}

class _FloatingBubblesState extends State<_FloatingBubbles> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => SizedBox(
        width: 40,
        height: 40,
        child: Stack(
          children: [
            Positioned(
              top: 4 + _ctrl.value * 4,
              right: 0,
              child: _bubble(10, const Color(0xFFFF6B6B)),
            ),
            Positioned(
              bottom: 2 + _ctrl.value * 3,
              left: 0,
              child: _bubble(8, const Color(0xFF4ECDC4)),
            ),
            Positioned(
              top: 14 + _ctrl.value * 2,
              left: 12,
              child: _bubble(6, const Color(0xFFFFE66D)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bubble(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color.withOpacity(0.8), shape: BoxShape.circle),
    );
  }
}
